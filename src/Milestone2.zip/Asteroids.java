
/*
CLASS: AsteroidsGame
DESCRIPTION: Extending Game, Asteroids is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.
Original code by Dan Leyzberg and Art Simon
 */
import java.awt.*;

public class Asteroids extends Game {
	public static final int SCREEN_WIDTH = 800;
	public static final int SCREEN_HEIGHT = 600;

	static int counter = 0;

	Asteroid tri;
	Asteroid sqr;
	Asteroid plg;
	Ship ship;
	
	public Asteroids() {
		super("Asteroids!", SCREEN_WIDTH, SCREEN_HEIGHT);
		this.setFocusable(true);
		this.requestFocus();
		
		Point b1 = new Point (0,80);
		Point b2 = new Point (60,60);
		Point b3 = new Point (20,0);
		Point[] triangle = {b1,b2,b3};
		Point a1 = new Point (0,50);
		Point a2 = new Point (80,30);
		Point a3 = new Point (60,60);
		Point a4 = new Point (20,0);
		Point[] square = {a1,a3,a2,a4};
		Point c1 = new Point (0,60);
		Point c2 = new Point (40,80);
		Point c3 = new Point (80,60);
		Point c4 = new Point (80,0);
		Point c5 = new Point(0,0);
		Point[] polygon = {c1,c2,c3,c4,c5};
		Point p1 = new Point(0,30);
		Point p2 = new Point(50,15);
		Point p3 = new Point(0,0);
		Point p4 = new Point(15,15);
		Point[] coolShip = {p1,p2,p3,p4};
		Point locationT = new Point(50,35);
		Point locationS = new Point(400,420);
		Point locationP = new Point(150,300);
		Point locationShip = new Point(0,300);
		tri = new Asteroid(triangle,locationT,0.8);
		sqr = new Asteroid(square,locationS,-0.2);
		plg = new Asteroid(polygon,locationP,0.5);
		ship = new Ship(coolShip,locationShip,10);
		
	}

	public void paint(Graphics brush) {
		brush.setColor(Color.black);
		brush.fillRect(0,0,width,height);

		// sample code for printing message for debugging
		// counter is incremented and this message printed
		// each time the canvas is repainted
		counter++;
		brush.setColor(Color.white);
		tri.paint(brush,Color.white);
		sqr.paint(brush,Color.white);
		plg.paint(brush, Color.white);
		ship.paint(brush, Color.pink);
		tri.move();
		sqr.move();
		plg.move();
		ship.move();
		brush.setColor(Color.white);
		brush.drawString("Counter is " + counter,10,10);
	}

	public static void main (String[] args) {
		Asteroids a = new Asteroids();
		a.repaint();
		
		
		//Asteroid aster = new Asteroid(null,null,0.3);
	}
}